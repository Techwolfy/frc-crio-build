/*************************************************************
*
*     Registers files as clients for dynamic content. To register a file as a dynamic content client, 
*		add the name of your CHM file to the alldynamicclients array on a new line, followed by a comma.
*		However, the last file in the list should NOT be followed by a comma.
*				  
*************************************************************/
var alldynamicclients = new Array(
	"addonlicensing",
	"criodevicehelp",
	"DataFinderTK",
	"daqmxtutorial",
	"embserial",
	"embsharedvi",
	"expresswb",
	"glang",
	"gmath",
	"gswoict",
	"frc",
	"frcdialog",
	"ftc",
	"fischtech",
	"inlinecnode",
	"internet",
	"lvaft",
	"lvaftconcepts",
	"lvarmdialog",
	"lvarmhelp",
	"lvasptconcepts",
	"lvcdsimshrd",
	"lvcdtextmath",
	"lvcgenhelp",
	"lvconcepts",
	"lvctrldsgn",
	"lvdaqmx",
	"lvdatabase",
	"lvdettmerge",
	"lvdfdtconcepts",
	"lvdigfiltdestk",
	"lvdscconcepts",
	"lvdsc",
	"lvdschelp",
	"lvdscprop",
	"lvept",
	"lveptconcepts",
	"lvfpga",
	"lvfpgaconcepts",
	"lvfpgahelp",
	"lvfpgamain",
	"lvhyperdev",
	"lvhyperref",
	"lvioscan",
	"lvjitterphtk",
	"lvmve",
	"lvnxt",
	"lvoffice",
	"lvpdadialog",
	"lvpdagsm",
	"lvpid",
	"lvpidmain",
	"lvrgthelp",
	"lvrobodialog",
	"lvrobogsm",
	"lvrobovi",
	"lvrtdialog",
	"lvrtconcepts",
	"lvrthowto",
	"lvrthelp",
	"lvrtvihelp",
	"lvsc",
	"lvscconcepts",
	"lvschowto",
	"lvsim",
	"lvsimconcepts",
	"lvsimemi",
	"lvsimesi",
	"lvsimhowto",
	"lvsimtkconcepts",
	"lvsitconcepts",
	"lvsysid",
	"lvsysidconcepts",
	"lvtextmath",
	"lvtextmathmain",
	"lvtimefreqtk",
	"lvtimeseriestk",
	"lvtpcdialog",
	"lvtpcgsm",
	"lvtrace",
	"lvtracehelp",
	"lvutfconcepts",
	"lvutf",
	"lvwavelettk",
	"lvwsnhelp",
	"lvvianalyzer",
	"lvxpe",
	"msureasstvi",
	"mxcncpts",
	"nimclvfb",	
	"oictref",
	"optsenmain",
	"optsenref",
	"p2pstreamhelp",
	"riohelprt",
	"robocrio",
	"robocriodialog",
	"sndvibtk",
	"sndvibasst",
	"svmain",
	"target2devicehelp",
	"veristand",
	"veristandmerge",
	"veristandsdapi",
	"vsexecapi"
	);

//Registers files as clients for single-sourced dynamic content
//(typically, this content is sourced in XML and displayed in database-generated topics)
var ss_dynamic_clients = new Array ("lvrthelp","lvfpga","lvpdagsm","lvtpcgsm");

for (i = 0; i < alldynamicclients.length; i++) {
	var client = alldynamicclients[i];
	var chm_js = "ms-its:" + client + ".chm::/" + client + ".js";
	include_js(chm_js);
}


